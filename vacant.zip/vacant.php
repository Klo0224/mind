<?php

include("auth.php");

// Fetch the profile image path
$StudentProfileImage = 'images/blueuser.svg'; // Default image
$sql = "SELECT profile_image FROM users WHERE id=17"; // Replace with dynamic ID
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $StudentProfileImage = $row['profile_image'];
}
$conn->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Availability</title>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css'>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #f4f7f6;
        }
        .dashboard-card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        .sidebar {
            transition: width 0.3s ease;
            width: 256px;
            min-width: 256px;
        }
        .sidebar.collapsed {
            width: 80px;
            min-width: 80px;
        }
        .main-content {
            transition: margin-left 0.3s ease;
            margin-left: 256px;
        }
        .main-content.expanded {
            margin-left: 80px;
        }
        .menu-item {
            transition: all 0.3s ease;
        }
        .menu-item:hover {
            background-color: #f3f4f6;
        }
        .menu-item.active {
            color: #1cabe3;
            background-color: #eff6ff;
            border-right: 4px solid #1cabe3;
        }
        .menu-text {
            transition: opacity 0.3s ease;
        }
        .sidebar.collapsed .menu-text {
            opacity: 0;
            display: none;
        }
        .section {
            display: none;
        }
        .section.active {
            display: block;
        }
        .content-section {
            display: none;
        }
        
        .content-section.active {
            display: block;
        }
        
    </style>
</head>
<body class="bg-gray-50">
    <!-- Sidebar -->
    <div id="sidebar" class="sidebar fixed top-0 left-0 h-screen bg-white shadow-lg z-10">
        <!-- Logo Section -->
        <div class="flex items-center p-6 border-b">
            <div class="w-15 h-10 rounded-full flex items-center justify-center">
                <a href="#"><img src="images/Mindsoothe(2).svg" alt="Mindsoothe Logo"></a>
            </div>
        </div>

        <!-- Menu Items -->
        <nav class="mt-6">
            <a href="#" class="menu-item flex items-center px-6 py-3" data-section="dashboard" id="gracefulThreadItem">
                <img src="images/gracefulThread.svg" alt="Graceful Thread" class="w-5 h-5">
                <span class="menu-text ml-3">Graceful Thread</span>
            </a>
            <a href="#" class="menu-item flex items-center px-6 py-3 text-gray-600" data-section="appointments" id="MentalWellness">
                <img src="images/Vector.svg" alt="Mental Wellness Companion" class="w-5 h-5">
                <span class="menu-text ml-3">Mental Wellness Companion</span>
            </a>
            <a href="#" class="menu-item active flex items-center px-6 py-3 text-gray-600" data-section="profile" id="ProfileItem">
                <img src="images/profile.svg" alt="Mental Wellness Companion" class="w-4 h-4">
                <span class="menu-text ml-3">Profile</span>
            </a>
        </nav>
        <div class="absolute bottom-0 w-full border-t">
            <!-- Logout -->
            <a href="landingpage.html" class="menu-item flex items-center px-6 py-4 text-red-500 hover:text-red-700">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
                <span class="menu-text ml-3">Logout</span>
            </a>  
        </div>
    </div>
    <div class="pl-64">

    <div class="bg-white rounded-lg shadow-md p-6 mb-8" style="width: 1200px; margin-left: 13px; margin-top: 30px">
    <div class="flex items-center">
    <div class="relative">
    <img id="profileImage" 
         src="<?php echo isset($_SESSION['profile_image']) ? htmlspecialchars($_SESSION['profile_image']) : 'images/blueuser.svg'; ?>" 
         alt="Profile Picture" 
         class="w-24 h-24 rounded-full object-cover">
    <label for="fileInput" class="absolute bottom-0 right-0 bg-blue-500 rounded-full p-2 cursor-pointer hover:bg-blue-600">
        <svg class="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
        </svg>
    </label>
    <input type="file" 
           id="fileInput" 
           class="hidden" 
           accept="image/*">
</div>
                    <div class="ml-6">
                    <h2 class="text-2xl font-bold"><?php echo $fullName; ?></h2>
                    <p class="text-gray-600">Department: <?php echo $Department; ?></p>
                    </div>
                </div>
            </div>


    <div class="p-8 ml-4">
        <!-- Header -->
        <div class="mb-6 ">
            <h1 class="text-2xl font-bold text-gray-800">My Available Time</h1>
            <p class="text-gray-600">Set your vacant time slots for counseling</p> 
        </div>

      <!-- Add New Time Slot Form -->
<div class="bg-white rounded-lg shadow-sm p-6 mb-6">
    <form id="addTimeForm" class="flex flex-wrap gap-4">
        <div class="w-full md:w-auto">
            <select name="day" required class="w-full md:w-48 p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                <option value="">Select Day</option>
                <option value="Monday">Monday</option>
                <option value="Tuesday">Tuesday</option>
                <option value="Wednesday">Wednesday</option>
                <option value="Thursday">Thursday</option>
                <option value="Friday">Friday</option>
            </select>
        </div>
        

        <div class="w-full md:w-auto">
            <input type="time" name="start_time" required 
                   min="07:30" max="17:00" 
                   class="w-full md:w-40 p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
        </div>
        
        <div class="w-full md:w-auto">
            <input type="time" name="end_time" required 
                   min="07:30" max="17:00"
                   class="w-full md:w-40 p-2 border rounded focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
        </div>
        


        <div class="w-full md:w-auto">
            <button type="submit" class="w-full md:w-auto bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
                Add Time Slot
            </button>
        </div>
    </form>
</div>

        <!-- Time Slots Table -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Day</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Time</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">End Time</th>
                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <!-- Time slots will be inserted here -->
        </tbody>
    </table>
    <div id="emptyState" class="hidden p-4 text-center text-gray-500">
        No time slots available
    </div>
</div>

    <script>// Section switching functionality
    document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('addTimeForm');
    const startTimeInput = form.querySelector('[name="start_time"]');
    const endTimeInput = form.querySelector('[name="end_time"]');
    
     // Function to validate time range
function validateTimeRange(startTime, endTime) {
    // Convert 12-hour time to minutes
    const timeToMinutes = (time) => {
        const [time12, period] = time.split(' ');
        let [hours, minutes] = time12.split(':').map(Number);
        
        if (period === 'PM' && hours !== 12) hours += 12;
        if (period === 'AM' && hours === 12) hours = 0;
        
        return hours * 60 + minutes;
    };

    const startMinutes = timeToMinutes(startTime);
    const endMinutes = timeToMinutes(endTime);

    if (endMinutes <= startMinutes) {
        return {
            isValid: false,
            message: 'End time must be later than start time'
        };
    }

    return { isValid: true };
}

// Form submission validation
form.addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = {
        day: form.querySelector('[name="day"]').value,
        start_time: startTimeInput.value,
        end_time: endTimeInput.value,
        user_id: 1
    };

    try {
        const response = await fetch('get_vacant.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();
        
        console.log('Server response:', result);

        if(result.success) {
            alert('Time slot saved successfully!');
            loadTimeSlots();
            form.reset();
        } else {
            alert('Error: ' + (result.error || 'Unknown error'));
            console.error('Server error details:', result);
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to save time slot: ' + error.message);
    }
});
});

// Function to load time slots
// Function to load time slots
async function loadTimeSlots() {
    try {
        const response = await fetch('get_vacant.php');
        
        // Add detailed logging
        console.log('Response status:', response.status);
        console.log('Content-Type:', response.headers.get('Content-Type'));
        
        const text = await response.text();
        console.log('Raw response:', text);
        
        let timeSlots;
        try {
            timeSlots = JSON.parse(text);
        } catch (parseError) {
            console.error('JSON Parsing Error:', parseError);
            throw new Error('Invalid JSON response: ' + text);
        }

        console.log('Parsed time slots:', timeSlots);

        const tbody = document.querySelector('table tbody');
        tbody.innerHTML = ''; 

        if (!Array.isArray(timeSlots) || timeSlots.length === 0) {
            document.getElementById('emptyState').classList.remove('hidden');
            return;
        }

        document.getElementById('emptyState').classList.add('hidden');

        timeSlots.forEach(slot => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${slot.day_of_week}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${slot.start_time}</td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${slot.end_time}</td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onclick="deleteTimeSlot(${slot.id})" class="text-red-600 hover:text-red-900">Delete</button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading time slots:', error);
        const errorDiv = document.createElement('div');
        errorDiv.className = 'text-red-600 p-4';
        errorDiv.textContent = 'Failed to load time slots: ' + error.message;
        document.querySelector('table').before(errorDiv);
    }
}

// Function to delete time slot
async function deleteTimeSlot(id) {
    if (!confirm('Are you sure you want to delete this time slot?')) {
        return;
    }

    try {
        const response = await fetch(`get_vacant.php?id=${id}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        
        if (result.success) {
            loadTimeSlots(); // Reload the table
        } else {
            alert(result.error || 'Failed to delete time slot');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Failed to delete time slot. Please try again later.');
    }
}

// Load time slots when page loads
document.addEventListener('DOMContentLoaded', loadTimeSlots);
</script>
<script src="sidebarnav.js"></script>

<script>
                document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('fileInput');
    const profileImage = document.getElementById('profileImage');
    const userName = document.getElementById('userName');
    const userDepartment = document.getElementById('userDepartment');

    if (fileInput && profileImage) {
        fileInput.addEventListener('change', function() {
            const selectedFile = this.files[0];
            if (!selectedFile) return;

            const confirmation = confirm('Are you sure you want to change your profile picture?');
            if (!confirmation) {
                this.value = '';
                return;
            }

            const formData = new FormData();
            formData.append('profileImage', selectedFile);

            profileImage.style.opacity = '0.5';

            fetch('stud_details.php', {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    profileImage.src = data.newImagePath;
                    // Update name and department if provided
                    if (data.firstName && data.lastName) {
                        userName.textContent = data.firstName + ' ' + data.lastName;
                    }
                    if (data.department) {
                        userDepartment.textContent = data.department;
                    }
                    alert('Profile image updated successfully!');
                } else {
                    if (data.message === 'User not authenticated') {
                        window.location.href = 'Login.html';
                    } else {
                        alert('Error updating profile image: ' + data.message);
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the profile image.');
            })
            .finally(() => {
                profileImage.style.opacity = '1';
            });
        });
    } else {
        console.error('Required elements not found. Check your HTML IDs.');
    }
});
            </script>
    </div>
    </div>
</body>
</html>