<?php
session_start();
include("connect.php");
header('Content-Type: application/json');

// Check if user is logged in using email
if (!isset($_SESSION['email'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profileImage'])) {
    $email = $_SESSION['email'];
    
    // Get complete user information
    $stmt = $conn->prepare("SELECT id, firstName, lastName, Department, profile_image FROM Users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        echo json_encode(['success' => false, 'message' => 'User not found']);
        $stmt->close();
        exit;
    }
    
    $user = $result->fetch_assoc();
    $user_id = $user['id'];
    $firstName = $user['firstName'];
    $lastName = $user['lastName'];
    $department = $user['Department'];
    
    $file = $_FILES['profileImage'];
    $fileName = $file['name'];
    $fileTmpName = $file['tmp_name'];
    $fileError = $file['error'];
    $fileSize = $file['size'];
    $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

    // Allowed file types
    $allowed = ['jpg', 'jpeg', 'png', 'gif'];
    
    // Validation
    if ($fileError !== 0) {
        echo json_encode(['success' => false, 'message' => 'Error uploading file']);
        exit;
    }
    
    if (!in_array($fileExt, $allowed)) {
        echo json_encode(['success' => false, 'message' => 'Invalid file type']);
        exit;
    }
    
    if ($fileSize > 5000000) { // 5MB max
        echo json_encode(['success' => false, 'message' => 'File too large']);
        exit;
    }

    // Create a user-specific directory
    $userDirectory = 'uploads/profiles/' . $user_id . '/';
    if (!file_exists($userDirectory)) {
        mkdir($userDirectory, 0777, true);
    }
    
    // Create unique filename using user_id and timestamp
    $newFileName = 'profile_' . time() . '.' . $fileExt;
    $uploadPath = $userDirectory . $newFileName;
    
    // Move uploaded file
    if (move_uploaded_file($fileTmpName, $uploadPath)) {
        // Delete old profile image if it exists and isn't the default
        if ($user['profile_image'] && $user['profile_image'] !== 'images/blueuser.svg') {
            if (file_exists($user['profile_image'])) {
                unlink($user['profile_image']);
            }
        }
        
        // Update database with user-specific path
        $stmt = $conn->prepare("UPDATE Users SET profile_image = ? WHERE id = ?");
        $stmt->bind_param("si", $uploadPath, $user_id);
        
        if ($stmt->execute()) {
            // Update only necessary session variables
            $_SESSION['profile_image'] = $uploadPath;
            
            echo json_encode([
                'success' => true,
                'newImagePath' => $uploadPath,
                'message' => 'Profile image updated successfully'
            ]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Database update failed']);
        }
        
        $stmt->close();
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to move uploaded file']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
}

$conn->close();
?>